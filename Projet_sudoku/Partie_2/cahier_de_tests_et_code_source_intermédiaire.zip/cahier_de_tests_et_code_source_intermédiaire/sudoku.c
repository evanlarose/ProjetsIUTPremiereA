/**
* @file sudoku.c
* @brief programme jeu de sudoku
* @author Evan Larose
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

//definition des constantes
const int TAILLE = 9;
const int N = 3;

//definition des variables globales
tGrille grille1;
int numLigne, numColonne, valeur;

//definition des types utilisateurs
typedef int tGrille[TAILLE, TAILLE];

//definition des prototypes
void chargerGrille(tGrille g);
void afficherGrille(tGrille g);
bool zeroDansGrille(tGrille g);
void saisir(int valeur);
bool possible(tGrille g, int ligne, int colonne, int valeur);

//definition du programme principal 
int main()
{
    //appel de la procdure chargerGrille
    chargerGrille(grille1);

    while(zeroDansGrille(grille1) == true)
    {
        //appel de la procdure afficherGrille
        afficherGrille(grille1);
        
        //saisie des indices de case et appel de la procedure saisir
        printf("Indices de la case ?\n");
        saisir(numLigne);
        saisir(numColonne);

        //verification de la possiblité d'inserer une valeur dans la case choisie
        if(grille1[numLigne][numColonne] != 0)
        {
            //message indiquant que la case choisie est deja occupée
            printf("IMPOSSIBLE, la case n'est pas libre.\n");
        }
        else
        {
            //saisie de la valeur à inserer dans la case choisie et appel de la procedure saisir
            printf("Valeur à insérer ?\n");
            saisir(valeur);

            //verification de la possibilité d'inserer la valeur choisie dans la case
            if (possible(grille1, numLigne, numColonne, valeur))
            {
                //insertion de la valeur choisie dans la grille
                grille1[numLigne][numColonne] = valeur;
            }
        }
    }
    //message de fin de partie
    printf("Grille pleine, fin de partie\n");
    return EXIT_SUCCESS;
}


//definition de la procedure de recuperation de la grille à partir d'un fichier dont le nom est lu au clavier
void chargerGrille(tGrille g)
{
    char nomFichier[30];
    FILE * f;

    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    if (f==NULL){
        printf("\n ERREUR sur le fichier %s\n", nomFichier);
    } else {
        fread(g, sizeof(int), TAILLE*TAILLE, f);
    }
    fclose(f);
}

//definition de la procedure qui affiche la grille
// void afficherGrille(tGrille g)
// {
//  
// }

//definition de la fonction qui verifie si la grille est remplie ou non
// bool zeroDansGrille(tGrille g)
// {
//  
// }

//definition de la procedure permettant de saisir les valeurs de colonne, ligne et valeur à insérer
// void saisir(int *adr_val)
// {
//  
// }

//definition de la fonction de verification des valeurs saisies
// bool possible(tGrille g, int ligne, int col, int val)
// {
//  
// }